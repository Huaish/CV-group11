import cv2
import numpy as np
import matplotlib.pyplot as plt
from numpy.fft import fft2, ifft2, fftshift, ifftshift
from filter import filter

# Read the image
image = cv2.imread('my_data/task2.jpg', 0)

def compute_spectrum(image):
    # Compute the 2D Fourier Transform
    dft = fft2(image)
    dft_shift = fftshift(dft)

    # Compute the magnitude spectrum
    magnitude_spectrum = 20 * np.log(np.abs(dft_shift))

    return magnitude_spectrum

def show_images(images, titles, spectra, spectrum_titles):
    n = len(images)
    plt.figure(figsize=(15, 5))
    for i in range(n):
        plt.subplot(2, n, i + 1)
        plt.imshow(images[i], cmap='gray')
        plt.title(titles[i])
        plt.axis('off')

        plt.subplot(2, n, i + n + 1)
        plt.imshow(spectra[i], cmap='jet')
        plt.title(spectrum_titles[i])
        plt.axis('off')
    plt.savefig("output/task2_my_data", bbox_inches='tight', pad_inches=0.1)

def gaussian_pyramid(image, levels):
    gaussian_images = [image]
    cutoff_frequency = 10
    
    for i in range(1, levels):
        smoothed = filter(image, cutoff_frequency, low_pass=True, filter_type='gaussian')
        
        downsampled = smoothed[::2, ::2]
        gaussian_images.append(downsampled)
        
        image = downsampled
    return gaussian_images

# Set the number of pyramid levels
levels = 6

# Create the Gaussian pyramid
gaussian_images = gaussian_pyramid(image, levels)

# Compute the spectra of the Gaussian pyramid images
spectra = [compute_spectrum(img) for img in gaussian_images]

# Set the titles for the images
titles = [f'Gaussian {i}' for i in range(len(gaussian_images))]
spectrum_titles = [f'Spectrum {i}' for i in range(len(spectra))]

# Display the Gaussian pyramid images and their spectra
all_images = gaussian_images
titles = [f'Gaussian {i}' for i in range(len(gaussian_images))]

show_images(gaussian_images, titles, spectra, spectrum_titles)